using Lab.Server.BlazorApp.Models;
using Lab.Server.BlazorApp.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.QuickGrid;

namespace Lab.Server.BlazorApp.Pages
{
    public partial class FetchSalesData
    {

        [Inject]
        private ISalesDataService? SalesDataService { get; set; }

        private IQueryable<SalesData>? salesDatas;

        string nameFilter = string.Empty;

        protected override async Task OnInitializedAsync()
        {
            string datafilePath = Path.Combine(Directory.GetCurrentDirectory() as string, "Data", "Data.csv");
            salesDatas = (await SalesDataService!.FetchSalesDataFromCsvFile(datafilePath)).AsQueryable();
        }

        PaginationState pagination = new() { ItemsPerPage = 25 };

        IQueryable<SalesData>? FilteredItems => salesDatas?.Where(x => x.Country.Contains(nameFilter, StringComparison.CurrentCultureIgnoreCase));

    }
}