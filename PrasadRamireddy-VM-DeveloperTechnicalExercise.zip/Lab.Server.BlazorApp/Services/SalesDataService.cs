﻿using CsvHelper;
using Lab.Server.BlazorApp.Models;
using System.Globalization;
using System.Text;

namespace Lab.Server.BlazorApp.Services
{
    public class SalesDataService : ISalesDataService
    {
        public Task<List<SalesData>> FetchSalesDataFromCsvFile(string csvFileName)
        {
            var result = new List<SalesData>();
            using (var reader = new StreamReader(csvFileName, Encoding.GetEncoding("iso-8859-1")))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                csv.Context.RegisterClassMap<SalesDataMap>();
                result = csv.GetRecords<SalesData>().ToList();
            }

            return Task.FromResult(result);
        }
    }
}
