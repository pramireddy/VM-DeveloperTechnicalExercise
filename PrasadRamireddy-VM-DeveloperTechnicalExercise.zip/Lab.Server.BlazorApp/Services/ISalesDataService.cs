﻿using Lab.Server.BlazorApp.Models;

namespace Lab.Server.BlazorApp.Services
{
    public interface ISalesDataService
    {
        Task<List<SalesData>> FetchSalesDataFromCsvFile(string csvFileName);
    }
}