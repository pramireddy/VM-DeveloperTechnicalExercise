using Lab.Server.BlazorApp.Models;
using Microsoft.AspNetCore.Components;

namespace Lab.Server.BlazorApp.Components
{
    public partial class SearchComponent
    {

        [Parameter]
        public IQueryable<SalesData>? FilteredItems { get; set; }

        [Parameter]
        public EventCallback<string> OnSearch { get; set; }

        private string searchterm = string.Empty;

        private async Task onSearchClick()
        {
            await OnSearch.InvokeAsync(searchterm);
        }
    }
}