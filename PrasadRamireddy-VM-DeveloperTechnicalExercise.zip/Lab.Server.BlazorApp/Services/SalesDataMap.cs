﻿using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using Lab.Server.BlazorApp.Models;

namespace Lab.Server.BlazorApp.Services
{
    public class SalesDataMap : ClassMap<SalesData>
    {
        readonly string format = "dd/MM/yyyy";
        readonly CultureInfo enGB = CultureInfo.GetCultureInfo("es-GB");
        public SalesDataMap()
        {
            Map(p => p.Segment).Index(0);
            Map(p => p.Country).Index(1);
            Map(p => p.Product).Index(2);
            Map(p => p.DiscountBand).Index(3);
            Map(p => p.UnitsSold).Index(4);
            Map(p => p.ManufacturingPrice).Index(5).TypeConverter(new PriceTypeConverter());
            Map(p => p.SalePrice).Index(6).TypeConverter(new PriceTypeConverter());
            Map(p => p.Date).TypeConverterOption.Format(format).TypeConverterOption.CultureInfo(enGB).Index(7);
        }

        internal class PriceTypeConverter : DefaultTypeConverter
        {
            public override object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
            {
                if (string.IsNullOrEmpty(text.Trim()))
                {
                    return decimal.Parse("0.00", NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);
                }
                // remove £ symbol
                string price = text.Replace("£", string.Empty);

                return decimal.Parse(price, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);

            }
        }
    }
}
