﻿namespace Lab.Server.BlazorApp.Models
{
    public class SalesData
    {
        public required string Segment { get; set; }
        public required string Country { get; set; }
        public required string Product { get; set; }
        public string? DiscountBand { get; set; }
        public string? UnitsSold { get; set; }
        public decimal ManufacturingPrice { get; set; }
        public decimal SalePrice { get; set; }
        public DateTime Date { get; set; }
    }
}
